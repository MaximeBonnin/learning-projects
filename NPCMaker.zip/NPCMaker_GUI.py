from NPCMaker import *
from tkinter import *
from tkinter import messagebox

root = Tk()

root.title("NPC maker")

text = StringVar()
main_list = Label(root, textvariable=text)
text.set(npc_list)
# main_list.pack()

root.geometry("400x500")

def new():
    add_npc()
    npc_list = read_npcs()
    text.set(npc_list)

def clear():
    messagebox.showwarning('Sure you wanna clear em?', 'Your NPCs will be scattered in the wind')
    reset_npcs()
    npc_list = read_npcs()
    text.set(npc_list)


deletem = Button(root, text="Clear NPCs", command=clear)
deletem.pack()

make_new = Button(root, text="New NPC", command=new)
make_new.pack()

main_list.pack()

root.mainloop()

