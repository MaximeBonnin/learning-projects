# Random Character creator
from bs4 import BeautifulSoup as soup
from urllib.request import urlopen as uReq
from random import randint
# import csv

class Char:
    def __init__(self, name, race, job, dndclass, voice, sex):
        self.name = name
        self.race = race
        self.job = job
        self.dndclass = dndclass
        self.voice = voice
        self.sex = sex

    def attributes(self):
        return (self.name, self.sex, self.race, self.dndclass, self.job, self.voice)

    def introduce(self):
        intro = "Hello! I am {}, a {} {} {}. " \
                "I work as a {} and my voice is '{}'.".format(self.name, self.sex, self.race,
                                                              self.dndclass, self.job, self.voice)
        return intro


# TODO complete lists
CharJobs = ["smith", "cook", "farmer", "guard", "lumberjack", "builder", "mail delivery person", "domestic servant",
            "general servant", "carpenter", "hunter", "shop owner", "miner", "clothes manufacturer", "herbalist"]
CharClasses = ["fighter", "cleric", "monk", "paladin", "artificer",
               "barbarian", "warlock", "rogue", "wizard", "ranger", "sorcerer", "druid", "bard"]
CharVoices = ["high pitch", "low pitch", "slow", "fast", "old", "young", "crazy", "russian accented", "german accented"]
CharRaces = ["human", "elf", "drow", "half-elf", "dwarf", "half-orc", "dragonborn", "tiefling", "goliath"]
CharSex = ["male","female"]


def FindName(race):
    # use random fantasy name creator https://www.fantasynamegen.com/{race}/short/
    # works for: elf, human, orc, dwarf, dragon(medium sug.), demon(medium sug.), halfling=hobbit, goliath=barbarian
    if race == "dragonborn":
        race = "dragon"
    elif race == "half-orc":
        race = "orc"
    elif race == "half-elf" or "drow":
        race = "elf"
    elif race == "tielfing":
        race = "demon"
    elif race == "goliath":
        race = "barbarian"
    elif race == "halfling":
        race = "hobbit"
    my_url = "https://www.fantasynamegen.com/" + race + "/short/"
    client = uReq(my_url)
    html = client.read()
    client.close()
    page_soup = soup(html, "html.parser")
    containers = page_soup.findAll("div", {"id": "main"})
    return containers[0].li.text

def CreateChar(name = ""):
    job = CharJobs[randint(1,len(CharJobs)-1)]
    cls = CharClasses[randint(1, len(CharClasses)-1)]
    voice = CharVoices[randint(1, len(CharVoices)-1)]
    race = CharRaces[randint(1, len(CharRaces)-1)]
    sex = CharSex[randint(1, len(CharSex)-1)]
    if name == "":
        name = FindName(race)

    NewChar = Char(name, race, job, cls, voice, sex)
    return NewChar

# print(CreateChar())

def add_npc(number = 1, name = ""):
    file1 = open("npcs.txt", "a")
    for i in range(0, number):
        new_NPC = CreateChar(name)
        # file1 = open("npcs.txt", "a")
        file1.write(str(new_NPC.attributes()) + "\n")
        # file1.close()

    file1.close()

add_npc()

def read_npcs():
    file2 = open("npcs.txt", "r")
    new_npcs = file2.read()
    file2.close()
    return new_npcs

npc_list = read_npcs()
print(npc_list)
# print(type(npc_list))

def reset_npcs():
    file3 = open("npcs.txt", "w")
    file3.write("")
    file3.close()

# print(read_npcs())
# print(len(read_npcs()))

